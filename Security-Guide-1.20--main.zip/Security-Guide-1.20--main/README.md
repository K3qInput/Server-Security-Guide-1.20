# Security-Guide-1.20-

1. LPX
2. ExploitFixer
3. Pl-Hide-Pro
4. Anti-Redstone-Clock
5. ZeroLag
6. Illegal Stacks Item Remover
7. T2cOp security
8. AntiCrasher
9. IP-Protect
10. Security Login
